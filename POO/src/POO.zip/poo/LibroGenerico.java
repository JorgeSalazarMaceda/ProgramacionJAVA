
package poo;

public class LibroGenerico {
            //Los atributos

        String isbn;
        String titulo;
        String autor;
        int numeroDePaginas;

        public LibroGenerico( String c) {
            titulo = "123";
            autor = "Desconocido";
            numeroDePaginas=300;
        }
        //Constructor con Parámetro

        public LibroGenerico() {
            autor = "Por defecto";
            titulo = "Nombre";
            
        }
        
        //Segunda parte
        //public LibroGenerico(String mititulo,String miautor,int numero){
           // titulo=mititulo;
        }
   // }
       

