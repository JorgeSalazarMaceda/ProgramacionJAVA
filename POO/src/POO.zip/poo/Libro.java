//generar la clase libro con 4 atributos, constructor que asigne valores a 3 aatributos 
//y un constructor por defecto que asigne valores a 2 atributos
package poo;

public class Libro {

    public static void main(String[] args) {
    LibroGenerico libro1=new LibroGenerico();
    LibroGenerico libro2=new LibroGenerico();
    
        System.out.println(libro1.titulo);
        System.out.println(libro2.titulo);
    }

}
