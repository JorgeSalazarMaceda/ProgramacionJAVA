// A continuacion se define un array de 5 alumnos que posteriormente se rellena, Por ultimo, se muestran los datos de los alumnos por pantalla, 
//pon los get y set.
package poo;

import java.util.Scanner;
public class Para_practicar_POO {
    //Atributos
    private String nombre;
    
    private double notaMedia;




    }
    

