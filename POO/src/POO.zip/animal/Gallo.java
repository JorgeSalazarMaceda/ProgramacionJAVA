
package animal;

public class Gallo extends Ave{
    //Constructor
//    public Gallo (){
//        super();
//    }
//    public Gallo (String come){
//        super();
//    }
    
    //Metodo
    @Override
    public void vuela(){
        System.out.println("Al gallo le cuesta volar");
        }
    
    
}
